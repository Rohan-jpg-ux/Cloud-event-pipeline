# Cloud-Native Event Pipeline

A serverless GCP pipeline that ingests, enriches, and stores **50K+ daily events** via Cloud Functions and Pub/Sub, with zero-touch CI/CD promotion across dev and prod.

## Architecture

```
Publisher → Pub/Sub Topic → Cloud Function → BigQuery (partitioned table)
                                ↑
                         GitHub Actions CI/CD
                         (lint → test → plan → deploy-dev → deploy-prod)
```

## Tech Stack

| Layer | Technology |
|---|---|
| Compute | GCP Cloud Functions (Python 3.11) |
| Messaging | GCP Pub/Sub |
| Storage | GCP BigQuery (daily partitioned) |
| IaC | Terraform |
| CI/CD | GitHub Actions |

## Project Structure

```
cloud-event-pipeline/
├── functions/
│   └── ingest/
│       ├── main.py          # Cloud Function entry point
│       └── requirements.txt
├── scripts/
│   ├── publisher.py         # Load-test / seed event publisher
│   └── setup_bq.py          # One-time BigQuery setup
├── terraform/
│   └── main.tf              # Pub/Sub, Cloud Function, GCS
├── tests/
│   └── test_ingest.py
└── .github/workflows/
    └── pipeline.yml         # CI/CD: test → plan → deploy-dev → deploy-prod
```

## Quick Start

### 1. Prerequisites

```bash
gcloud auth application-default login
pip install -r functions/ingest/requirements.txt
pip install pytest pytest-cov ruff
```

### 2. Bootstrap BigQuery

```bash
python scripts/setup_bq.py --project YOUR_PROJECT_ID
```

### 3. Deploy with Terraform

```bash
cd terraform
terraform init
terraform apply -var="project_id=YOUR_PROJECT_ID" -var="env=dev"
```

### 4. Publish Test Events

```bash
python scripts/publisher.py --project YOUR_PROJECT_ID --topic event-ingest-dev --count 1000
```

### 5. Run Tests Locally

```bash
pytest tests/ -v --cov=functions
```

## CI/CD Flow

| Branch | Trigger | Action |
|---|---|---|
| Pull Request | Open/Update | Lint + Test + Terraform Plan |
| `develop` push | Merge | Deploy → Dev |
| `main` push | Merge | Deploy → Prod (with rollback hook) |

## GitHub Secrets Required

| Secret | Description |
|---|---|
| `GCP_PROJECT_ID` | Your GCP project ID |
| `GCP_SA_KEY` | Service account JSON key (base64) |

## Performance

- **Latency**: < 1 second end-to-end (Pub/Sub → BigQuery)
- **Throughput**: Tested at 100K+ events/day
- **Cost**: Serverless — pay only per invocation
