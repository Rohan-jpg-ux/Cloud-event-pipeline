terraform {
  required_version = ">= 1.5"
  required_providers {
    google = {
      source  = "hashicorp/google"
      version = "~> 5.0"
    }
  }
}

provider "google" {
  project = var.project_id
  region  = var.region
}

# ── Variables ────────────────────────────────────────────────────────────────

variable "project_id" {
  description = "GCP project ID"
  type        = string
}

variable "region" {
  description = "GCP region"
  type        = string
  default     = "us-central1"
}

variable "env" {
  description = "Deployment environment (dev | prod)"
  type        = string
  default     = "dev"
}

# ── Pub/Sub ───────────────────────────────────────────────────────────────────

resource "google_pubsub_topic" "events" {
  name = "event-ingest-${var.env}"
}

resource "google_pubsub_subscription" "events_sub" {
  name  = "event-ingest-sub-${var.env}"
  topic = google_pubsub_topic.events.name

  ack_deadline_seconds = 30

  retry_policy {
    minimum_backoff = "10s"
    maximum_backoff = "600s"
  }
}

# ── Cloud Storage (function source) ──────────────────────────────────────────

resource "google_storage_bucket" "functions_bucket" {
  name          = "${var.project_id}-functions-${var.env}"
  location      = "US"
  force_destroy = true
}

data "archive_file" "ingest_zip" {
  type        = "zip"
  source_dir  = "${path.module}/functions/ingest"
  output_path = "${path.module}/.terraform/ingest.zip"
}

resource "google_storage_bucket_object" "ingest_zip" {
  name   = "ingest-${data.archive_file.ingest_zip.output_md5}.zip"
  bucket = google_storage_bucket.functions_bucket.name
  source = data.archive_file.ingest_zip.output_path
}

# ── Cloud Function ────────────────────────────────────────────────────────────

resource "google_cloudfunctions_function" "ingest" {
  name        = "event-ingest-${var.env}"
  description = "Ingest Pub/Sub events and write to BigQuery"
  runtime     = "python311"
  region      = var.region

  available_memory_mb   = 256
  source_archive_bucket = google_storage_bucket.functions_bucket.name
  source_archive_object = google_storage_bucket_object.ingest_zip.name
  entry_point           = "ingest_event"
  timeout               = 60

  event_trigger {
    event_type = "google.pubsub.topic.publish"
    resource   = google_pubsub_topic.events.name
  }

  environment_variables = {
    BQ_PROJECT = var.project_id
    BQ_DATASET = "event_pipeline"
    BQ_TABLE   = "raw_events"
  }
}

# ── Outputs ───────────────────────────────────────────────────────────────────

output "pubsub_topic" {
  value = google_pubsub_topic.events.name
}

output "function_name" {
  value = google_cloudfunctions_function.ingest.name
}
