"""
setup_bq.py — One-time setup: creates the BigQuery dataset and raw_events table.
Usage: python setup_bq.py --project <PROJECT>
"""

import argparse

from google.cloud import bigquery
from google.api_core.exceptions import Conflict

SCHEMA = [
    bigquery.SchemaField("event_id", "STRING", mode="REQUIRED"),
    bigquery.SchemaField("ingested_at", "TIMESTAMP", mode="REQUIRED"),
    bigquery.SchemaField("source", "STRING"),
    bigquery.SchemaField("event_type", "STRING"),
    bigquery.SchemaField("user_id", "STRING"),
    bigquery.SchemaField("session_id", "STRING"),
    bigquery.SchemaField("properties", "STRING"),  # JSON blob
    bigquery.SchemaField("pipeline_version", "STRING"),
]


def setup(project: str, dataset_id: str = "event_pipeline", table_id: str = "raw_events") -> None:
    client = bigquery.Client(project=project)

    # Dataset
    dataset = bigquery.Dataset(f"{project}.{dataset_id}")
    dataset.location = "US"
    try:
        client.create_dataset(dataset)
        print(f"Dataset {dataset_id} created.")
    except Conflict:
        print(f"Dataset {dataset_id} already exists.")

    # Table with partitioning on ingested_at
    table_ref = f"{project}.{dataset_id}.{table_id}"
    table = bigquery.Table(table_ref, schema=SCHEMA)
    table.time_partitioning = bigquery.TimePartitioning(
        type_=bigquery.TimePartitioningType.DAY,
        field="ingested_at",
    )
    try:
        client.create_table(table)
        print(f"Table {table_id} created with daily partitioning.")
    except Conflict:
        print(f"Table {table_id} already exists.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--project", required=True)
    args = parser.parse_args()
    setup(args.project)
