"""
publisher.py — Utility to publish test events to a GCP Pub/Sub topic.
Run locally:  python publisher.py --project <PROJECT> --topic <TOPIC> --count 100
"""

import argparse
import json
import random
import time
import uuid
from datetime import datetime, timezone

from google.cloud import pubsub_v1


EVENT_TYPES = ["page_view", "click", "purchase", "sign_up", "logout", "search"]
SOURCES = ["web", "ios", "android", "api"]


def build_event() -> dict:
    return {
        "event_id": str(uuid.uuid4()),
        "event_type": random.choice(EVENT_TYPES),
        "source": random.choice(SOURCES),
        "user_id": f"user_{random.randint(1, 10_000):05d}",
        "session_id": str(uuid.uuid4()),
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "properties": {
            "page": f"/page/{random.randint(1, 50)}",
            "duration_ms": random.randint(100, 5000),
            "referrer": random.choice(["google", "direct", "email", "social"]),
        },
    }


def publish_events(project: str, topic: str, count: int, delay: float) -> None:
    publisher = pubsub_v1.PublisherClient()
    topic_path = publisher.topic_path(project, topic)
    futures = []

    print(f"Publishing {count} events to {topic_path} …")
    for i in range(count):
        event = build_event()
        data = json.dumps(event).encode("utf-8")
        future = publisher.publish(topic_path, data)
        futures.append(future)
        if delay:
            time.sleep(delay)
        if (i + 1) % 100 == 0:
            print(f"  {i + 1}/{count} published")

    for f in futures:
        f.result()  # block until all ACKed
    print("Done.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Publish test events to Pub/Sub.")
    parser.add_argument("--project", required=True, help="GCP project ID")
    parser.add_argument("--topic", required=True, help="Pub/Sub topic name")
    parser.add_argument("--count", type=int, default=50_000, help="Number of events")
    parser.add_argument("--delay", type=float, default=0.0, help="Seconds between events")
    args = parser.parse_args()
    publish_events(args.project, args.topic, args.count, args.delay)
