"""
Cloud-Native Event Pipeline
GCP Cloud Functions entry point for event ingestion via Pub/Sub.
"""

import base64
import json
import logging
import os
from datetime import datetime, timezone

from google.cloud import bigquery

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

BQ_PROJECT = os.environ.get("BQ_PROJECT", "your-gcp-project")
BQ_DATASET = os.environ.get("BQ_DATASET", "event_pipeline")
BQ_TABLE = os.environ.get("BQ_TABLE", "raw_events")


def ingest_event(event: dict, context) -> None:
    """
    Cloud Function triggered by a Pub/Sub message.

    Args:
        event: Pub/Sub message payload (base64-encoded data + attributes).
        context: Cloud Function metadata (event_id, timestamp, etc.).
    """
    try:
        raw = base64.b64decode(event["data"]).decode("utf-8")
        payload = json.loads(raw)
    except (KeyError, ValueError) as exc:
        logger.error("Failed to decode Pub/Sub message: %s", exc)
        return

    enriched = _enrich(payload, context)
    _write_to_bigquery(enriched)
    logger.info("Event %s written to BigQuery.", enriched.get("event_id"))


def _enrich(payload: dict, context) -> dict:
    """Attach pipeline metadata to the raw event."""
    return {
        "event_id": context.event_id if context else payload.get("event_id", "local"),
        "ingested_at": datetime.now(timezone.utc).isoformat(),
        "source": payload.get("source", "unknown"),
        "event_type": payload.get("event_type", "generic"),
        "user_id": payload.get("user_id"),
        "session_id": payload.get("session_id"),
        "properties": json.dumps(payload.get("properties", {})),
        "pipeline_version": "1.0.0",
    }


def _write_to_bigquery(row: dict) -> None:
    """Insert a single enriched event row into BigQuery."""
    client = bigquery.Client(project=BQ_PROJECT)
    table_ref = f"{BQ_PROJECT}.{BQ_DATASET}.{BQ_TABLE}"
    errors = client.insert_rows_json(table_ref, [row])
    if errors:
        logger.error("BigQuery insertion errors: %s", errors)
        raise RuntimeError(f"BigQuery write failed: {errors}")
