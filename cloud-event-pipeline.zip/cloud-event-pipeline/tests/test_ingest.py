"""Unit tests for the ingest Cloud Function."""

import json
import base64
from unittest.mock import MagicMock, patch

import pytest

# We mock google.cloud.bigquery before importing main
import sys
sys.modules.setdefault("google", MagicMock())
sys.modules.setdefault("google.cloud", MagicMock())
sys.modules.setdefault("google.cloud.bigquery", MagicMock())

from functions.ingest.main import ingest_event, _enrich, _write_to_bigquery  # noqa: E402


def _make_event(payload: dict) -> dict:
    return {"data": base64.b64encode(json.dumps(payload).encode()).decode()}


def _make_context(event_id: str = "test-event-001"):
    ctx = MagicMock()
    ctx.event_id = event_id
    return ctx


class TestEnrich:
    def test_attaches_pipeline_metadata(self):
        payload = {"event_type": "page_view", "source": "web", "user_id": "u_001"}
        ctx = _make_context("evt-123")
        result = _enrich(payload, ctx)

        assert result["event_id"] == "evt-123"
        assert result["event_type"] == "page_view"
        assert result["source"] == "web"
        assert result["user_id"] == "u_001"
        assert result["pipeline_version"] == "1.0.0"
        assert "ingested_at" in result

    def test_defaults_unknown_source(self):
        result = _enrich({}, _make_context())
        assert result["source"] == "unknown"
        assert result["event_type"] == "generic"

    def test_properties_serialised_to_json_string(self):
        payload = {"properties": {"page": "/home", "duration_ms": 500}}
        result = _enrich(payload, _make_context())
        props = json.loads(result["properties"])
        assert props["page"] == "/home"


class TestIngestEvent:
    @patch("functions.ingest.main._write_to_bigquery")
    def test_happy_path(self, mock_write):
        payload = {"event_type": "click", "source": "ios", "user_id": "u_42"}
        event = _make_event(payload)
        ingest_event(event, _make_context())
        mock_write.assert_called_once()
        row = mock_write.call_args[0][0]
        assert row["event_type"] == "click"

    @patch("functions.ingest.main._write_to_bigquery")
    def test_invalid_base64_does_not_raise(self, mock_write):
        """Malformed messages should log and return without crashing."""
        ingest_event({"data": "!!not-base64!!"}, _make_context())
        mock_write.assert_not_called()

    @patch("functions.ingest.main._write_to_bigquery")
    def test_invalid_json_does_not_raise(self, mock_write):
        bad = base64.b64encode(b"not json").decode()
        ingest_event({"data": bad}, _make_context())
        mock_write.assert_not_called()
